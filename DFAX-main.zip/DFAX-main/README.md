# DFAX
Digital Forensic Artifact eXtractor is a open source project to extract artifacts from a EWF file or a device.
