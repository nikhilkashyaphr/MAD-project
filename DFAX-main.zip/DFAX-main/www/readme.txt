Requirements:
Webserver, Php, Sqlite
php-sqlite3
https://getbootstrap.com
https://jquery.com/
